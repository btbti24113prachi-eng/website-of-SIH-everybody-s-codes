import React, { useState, useEffect } from "react";
import MapPanel from "../components/MapPanel";

const TrafficControl = () => {
  const [signal, setSignal] = useState("Red");
  const [carCount, setCarCount] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setCarCount((prev) => prev + Math.floor(Math.random() * 3));
    }, 2000);
    return () => clearInterval(interval);
  }, []);

  const toggleSignal = () => {
    setSignal((prev) =>
      prev === "Red" ? "Green" : prev === "Green" ? "Yellow" : "Red"
    );
  };

  return (
    <div>
      <h1 className="text-2xl font-bold mb-4">Traffic Control</h1>
      <MapPanel />
      <div className="mt-4 flex gap-6">
        <div>
          <p>Current Signal: <span className="font-semibold">{signal}</span></p>
          <button
            onClick={toggleSignal}
            className="mt-2 px-4 py-2 bg-blue-600 text-white rounded"
          >
            Change Signal
          </button>
        </div>
        <div>
          <p>Car Count: {carCount}</p>
        </div>
      </div>
    </div>
  );
};

export default TrafficControl;