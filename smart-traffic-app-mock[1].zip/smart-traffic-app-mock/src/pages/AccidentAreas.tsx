import React from "react";
import MapPanel from "../components/MapPanel";

const AccidentAreas = () => {
  return (
    <div>
      <h1 className="text-2xl font-bold mb-4">Accident Areas</h1>
      <MapPanel />
      <ul className="mt-4 list-disc pl-5">
        <li>Delhi - Heavy congestion due to accident</li>
        <li>Mumbai - Accident cleared, traffic normal</li>
        <li>Bangalore - Ongoing road blockage</li>
      </ul>
    </div>
  );
};

export default AccidentAreas;