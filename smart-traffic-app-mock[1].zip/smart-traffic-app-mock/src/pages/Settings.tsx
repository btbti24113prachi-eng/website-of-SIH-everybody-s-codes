import React from "react";

const Settings = () => {
  return (
    <div>
      <h1 className="text-2xl font-bold mb-4">Settings</h1>
      <form className="space-y-4">
        <div>
          <label className="block">Notification Email</label>
          <input type="email" className="border p-2 rounded w-full" />
        </div>
        <div>
          <label className="block">User Role</label>
          <select className="border p-2 rounded w-full">
            <option>Admin</option>
            <option>Operator</option>
            <option>Viewer</option>
          </select>
        </div>
        <button type="submit" className="px-4 py-2 bg-green-600 text-white rounded">
          Save Settings
        </button>
      </form>
    </div>
  );
};

export default Settings;