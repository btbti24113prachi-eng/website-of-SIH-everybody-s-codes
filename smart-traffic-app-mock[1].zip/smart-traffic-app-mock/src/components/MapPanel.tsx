import React from "react";
import { MapContainer, TileLayer, Marker, Popup, Polygon } from "react-leaflet";
import "leaflet/dist/leaflet.css";

const accidentData = [
  { id: 1, city: "Delhi", coords: [28.61, 77.23] },
  { id: 2, city: "Mumbai", coords: [19.07, 72.87] },
  { id: 3, city: "Bangalore", coords: [12.97, 77.59] },
];

const congestionZones = [
  {
    id: 1,
    name: "Zone A",
    coords: [
      [28.62, 77.22],
      [28.62, 77.24],
      [28.60, 77.24],
      [28.60, 77.22],
    ],
    color: "red",
  },
  {
    id: 2,
    name: "Zone B",
    coords: [
      [28.63, 77.20],
      [28.63, 77.21],
      [28.61, 77.21],
      [28.61, 77.20],
    ],
    color: "orange",
  },
];

const MapPanel = () => {
  return (
    <div className="rounded overflow-hidden h-72">
      <MapContainer center={[28.61, 77.23]} zoom={12} className="h-full w-full">
        <TileLayer
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
          attribution="&copy; OpenStreetMap contributors"
        />

        {/* Accident markers */}
        {accidentData.map((accident) => (
          <Marker key={accident.id} position={accident.coords as [number, number]}>
            <Popup>Accident reported in {accident.city}</Popup>
          </Marker>
        ))}

        {/* Congestion polygons */}
        {congestionZones.map((zone) => (
          <Polygon
            key={zone.id}
            positions={zone.coords as [number, number][]}
            pathOptions={{ color: zone.color }}
          >
            <Popup>{zone.name} - Heavy traffic</Popup>
          </Polygon>
        ))}
      </MapContainer>
    </div>
  );
};

export default MapPanel;