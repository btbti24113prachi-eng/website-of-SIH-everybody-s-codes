import React from "react";
import { Routes, Route, Link } from "react-router-dom";
import Dashboard from "./pages/Dashboard";
import TrafficControl from "./pages/TrafficControl";
import AccidentAreas from "./pages/AccidentAreas";
import Settings from "./pages/Settings";

const App = () => {
  return (
    <div className="h-full flex flex-col">
      <nav className="bg-blue-600 text-white p-4 flex gap-6">
        <Link to="/">Dashboard</Link>
        <Link to="/traffic">Traffic Control</Link>
        <Link to="/accidents">Accident Areas</Link>
        <Link to="/settings">Settings</Link>
      </nav>
      <main className="flex-1 p-4 overflow-y-auto">
        <Routes>
          <Route path="/" element={<Dashboard />} />
          <Route path="/traffic" element={<TrafficControl />} />
          <Route path="/accidents" element={<AccidentAreas />} />
          <Route path="/settings" element={<Settings />} />
        </Routes>
      </main>
    </div>
  );
};

export default App;